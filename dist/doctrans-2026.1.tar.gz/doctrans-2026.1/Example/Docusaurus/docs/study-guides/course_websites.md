# Course Websites

This page contains course pages from online so you can follow the course and learn certain topics systematically.

## ECE

<details>
  <summary>
  UC Davis EEC 281 - VLSI Digital Signal Processing
  </summary>
  [UC Davis EEC 281 - VLSI Digital Signal Processing](https://www.ece.ucdavis.edu/~bbaas/281/)
  
  Winter 2025

  Instructor: Bevan Baas

  Digital signal processors, building blocks, and algorithms. Design and implementation of processor algorithms, architectures, control, functional units, and circuit topologies for increased performance and reduced circuit size and power dissipation.

  Goals: Through this course, students will develop the necessary skills to design simple synthesizable processors suitable for numerically intensive processing with an emphasis on small chip area and high-performance. Secondly, students will learn to design processors for simple digital signal processing tasks through the simultaneous design of DSP algorithms, processor architectures, and hardware design.

  ![Course Background](https://www.ece.ucdavis.edu/~bbaas/281/misc/header.700x250.jpg)
</details>

