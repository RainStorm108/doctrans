# Installation Notes on Vivado

Check the supported OS first, Vivado Design Suite might have weird issues even if the installtion goes well. To ensure stable and less hassel with the setup you should check the [supported OS for Vivado Design Suite](https://docs.amd.com/r/en-US/ug973-vivado-release-notes-install-license/Supported-Operating-Systems) to see what OS you would like to use.

```text title="According to Vivado Documentation for 2025.1"
AMD supports the following operating systems on x86-64 processor architectures.

Microsoft Windows Professional/Enterprise 10.0 22H2 Update
Microsoft Windows 11.0 23H2 and 24H2 Update
Red Hat Enterprise Workstation/Server 8.10, 9.2, 9.3, 9.4, and 9.5 (64-bit), English
SUSE Linux Enterprise 15 SP4 (64-bit), English
Amazon Linux 2 AL2 LTS (64-bit)
AlmaLinux 8.10, 9.4, and 9.5 (64-bit)
Ubuntu Linux 22.04.2, 22.04.3, 22.04.4, 22.04.5, 24.04, and 24.04.1 (64-bit), English
Rocky Linux 8.10
```

:::warning
It does not work well on unsupported OS, I tried on Debian12 but ended up with a lot of issues. Use supported OS to avoid unnecessary hassle.
:::

I used Ubuntu Linux 24.04.01, you can download older Ubuntu installtion files from [ubuntu releases index](https://old-releases.ubuntu.com/releases/24.04/).

- I Picked [ubuntu-24.04.1-desktop-amd64.iso (click the link to download)](https://old-releases.ubuntu.com/releases/24.04/ubuntu-24.04.1-desktop-amd64.iso).
- Make installtion USB drive using the iso file with the following software
  - if you are on Windows: [Rufus](https://rufus.ie/)
  - if you are on Mac/Linux: [balenaEtcher](https://etcher.balena.io/)
- Install Ubuntu OS
- Download and install Vitis using the [Official Guide](https://docs.amd.com/r/en-US/ug973-vivado-release-notes-install-license/Download-and-Installation)

:::tip
Once you finished installing `Ubuntu`, there are some dependencies you have to install.

**Ubuntu OS requires the libtinfo.so.5 according to Official AMD documentation for 2025.1**

<details>
  <summary>Install libtinfo.so</summary>
  ```bash title="How to install libtinfo5 on Ubuntu24.04"
  sudo apt update
  wget http://security.ubuntu.com/ubuntu/pool/universe/n/ncurses/libtinfo5_6.3-2ubuntu0.1_amd64.deb
  sudo apt install ./libtinfo5_6.3-2ubuntu0.1_amd64.deb
  ```
  [Source](https://askubuntu.com/questions/1531760/how-to-install-libtinfo5-on-ubuntu24-04)
</details>

You also have to install build essentials for gcc.
```bash title="Install build-essentials"
sudo apt install build-essential
```
:::

Ubuntu Linux 24.04