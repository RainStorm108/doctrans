# Verilog Notes

Verilog is a type of Hardware Description Language (HDL) used for define digital circuits. Another HDL commonly used is the systemverilog (a superset of verilog, fully backward compatible with verilog) and VHDL (Very High-Speed Integrated Circuit Hardware Description Language).

These languages are used to design and model hardware, such as FPGAs and ASICs. It describes the behavior of digital systems for simulation and allows these descriptions to be "synthesized" into actual electronic circuits.

## Resources

- [UC Davis 281 Verilog Handout](https://www.ece.ucdavis.edu/~bbaas/281/notes/Handout.verilog2.basics.pdf)
- [Verilog Quick Reference Guide by Stuart Sutherland](https://sutherland-hdl.com/pdfs/verilog_2001_ref_guide.pdf)
- [nandland verilog tutorial](https://nandland.com/learn-verilog/)
- [Verilog Practices](https://hdlbits.01xz.net/wiki/Main_Page)
- [Torpor module examples generator](https://www.torporip.com/#/)
- [Chipverify](https://www.chipverify.com/tutorials/verilog)

## Module

Modules are the fundamental building blocks for verilog, it encapsulates a specific piece of functionality.

```verilog title="module syntax"
`timescale <time_unit>/<time_precision>

module <module_name>([ports]);
  // Module content

endmodule;
```

### Example of Multiplexer Module

<table>
  <caption>Multiplexer Circuit and Code</caption>
  <tr>
    <th>Multiplexer</th>
    <th>Verilog Code of Multiplexer</th>
  </tr>
  <tr>
    <td style={{ textAlign: 'center' }}>
      <figure style={{ margin: 0, padding: 0 }}>
        <div style={{ backgroundColor: '#f0f0f0', padding: '10px', width: '200px', display: 'inline-block' }}>
          ![Multiplexer](./mux_image.png)
        </div>
        <figcaption style={{ fontSize: '0.8em' }}>
          <a href="https://upload.wikimedia.org/wikipedia/commons/thumb/3/39/Multiplexer_2-to-1.svg/1024px-Multiplexer_2-to-1.svg.png">Multiplexer</a> by <a href="https://en.wikipedia.org/wiki/User:Cburnett">Cburnett</a>, licensed under <a href="https://creativecommons.org/licenses/by-sa/3.0/deed.en">CC BY-SA 3.0</a>.
        </figcaption>
      </figure>
    </td>
    <td>
      ```verilog title="Multiplexer"
      `timescale 1ns/1ns

      module mux(a, b, sel, out);
        input a;
        input b;
        input sel;
        output out;

        assign out = (sel == 1) ? a : b;

      endmodule
      ```
    </td>
  </tr>
</table>

## Testbench

A Verilog testbench is a self-contained Verilog module used to verify the functional correctness of a design, referred to as the Device Under Test (DUT).

```verilog title="General Testbench Syntax"
`timescale 1ns/1ps

module <module_tb>;
  
  // DUT connections

  <module_name> <module_instance>(
      <link DUT to module ports>
    );

    initial begin
      <Testbench contents>
    end

endmodule

```


<details>
<summary>Example: Testbench for Multiplexer</summary>
```verilog title="Testbench for multiplexer module"
`timescale 1ns/1ns

module mux_tb();
  reg s_a;
  reg s_b;
  reg sel;
  wire out;

  mux mux_test(
    .a(s_a),
    .b(s_b),
    .sel(sel),
    .out(out)
  );

  initial begin
    s_a = 0;
    s_b = 0;
    sel = 0;
    #200  // Delay 200ns

    s_a = 0;
    s_b = 1;
    sel = 0;
    #200

    s_a = 0;
    s_b = 0;
    sel = 1;
    #200

    s_a = 0;
    s_b = 1;
    sel = 1;
    #200

    s_a = 1;
    s_b = 0;
    sel = 0;
    #200

    s_a = 1;
    s_b = 1;
    sel = 0;
    #200

    s_a = 1;
    s_b = 0;
    sel = 1;
    #200

    s_a = 1;
    s_b = 1;
    sel = 1;
    #200
  end
endmodule

```
</details>

We can then run the simulation on our module.
