import asyncio
import time

async def do_work(name, delay):
    print(f"{name}: start")
    await asyncio.sleep(delay)     # suspension point: lets other tasks run
    print(f"{name}: end after {delay}s")

async def main():
    t0 = time.perf_counter()
    # Schedule three coroutines concurrently
    await asyncio.gather(
        do_work("A", 1),
        do_work("B", 1),
        do_work("C", 1),
    )
    print(f"elapsed ~{time.perf_counter() - t0:.2f}s")

asyncio.run(main())
