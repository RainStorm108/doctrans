/**
 * @param {number[]} numbers
 * @param {number} target
 * @return {number[]}
 *
*/
var twoSum = function (numbers, target) {
  let left = 0, right = numbers.length - 1;

  while (left < right) {
    total = numbers[left] + numbers[right];
    if (total === target) {
      return [left + 1, right + 1];
    }
    else if (total > target) {
      right -= 1
    }
    else {
      left += 1
    }
  }
};


/**
 * @param {number[]} prices
 * @return {number}
 */
var maxProfit = function (prices) {
  let min = prices[0];
  let profit = 0;
  // slower than loop
  prices.forEach(element => {
    if (min > element) {
      min = element;
    }
    else {
      profit = Math.max(profit, element - min);
    }
  });
  return profit;
};

/**
 * @param {string} s
 * @return {boolean}
 */
function isAlphanum(c) {
  return (c >= "A" && c <= "Z") || (c >= "0" && c <= "9") || (c >= "a" && c <= "z");
}

var isPalindrome = function (s) {
  let left = 0, right = s.length - 1;
  while (left < right) {
    while (!isAlphanum(s[left]) && left < right) {
      left += 1;
    }
    while (!isAlphanum(s[right]) && left < right) {
      right -= 1;
    }

    if (s[left].toLowerCase() !== s[right].toLowerCase())
      return false;
    left += 1;
    right -= 1;
  }
  return true;
};

/**
 * @param {number[]} nums
 * @return {boolean}
 */
var containsDuplicate = function (nums) {
  let memo = new Set();
  for (const num of nums) {
    if (memo.has(num)) {
      return true;
    }
    else {
      memo.add(num);
    }
  }
  return false;
};

/**
 * @param {number[]} nums
 * @return {number}
 */
var longestConsecutive = function (nums) {
  let memo = new Set(nums);
  let res = 0;

  for (let i = 0; i < nums.length; i++) {
    // If in memo, skip
    if (!memo.has(nums[i])) {
      continue;
    }

    let counter = 1;
    let cur = nums[i];
    // To left
    while (memo.has(cur - 1)) {
      memo.delete(cur - 1);
      cur -= 1;
      counter += 1;
    }

    cur = nums[i];
    // To right
    while (memo.has(cur + 1)) {
      memo.delete(cur + 1)
      cur += 1;
      counter += 1;
    }

    res = Math.max(counter, res);
  }
  return res;
};



