let controller = new AbortController();
let signal = controller.signal;

controller.abort(); // Call abort

alert(signal.aborted);  // 

