function body_click(){
  const button = document.getElementById('body_button');
  button.addEventListener('click', hanlde_click);
}

function handle_click(){
  document.getElementById('test_text').textContent = "Clicked";
}

document.getElementById('body_button').addEventListener('click', 
  () => {
    document.getElementById('p_text').textContent = "clicked";
})