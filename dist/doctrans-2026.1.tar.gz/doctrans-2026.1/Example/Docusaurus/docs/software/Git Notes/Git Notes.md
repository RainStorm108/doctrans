# Git Notes


## Changing Commit Message After Push

[Source](https://stackoverflow.com/questions/8981194/changing-git-commit-message-after-push-given-that-no-one-pulled-from-remote)

```git
git commit --amend

or

git commit -m --amend
```

Enter the new commit message then

```git
git push --force-with-lease <repo> <branch>
```
